const handler = require('serve-handler');
const http = require('http');

const server = http.createServer((request, response) => {
  return handler(request, response, {
    public: '/home/user/webapp'
  });
});

server.listen(3000, '0.0.0.0', () => {
  console.log('Running at http://localhost:3000');
});
